import { Component, OnInit } from '@angular/core';
import { ITodo } from '@app/todos/interfaces';

@Component({
  selector: 'app-todos-list',
  styleUrls: [
    './todo-list.component.scss',
  ],
  templateUrl: './todo-list.component.html',
})
export class TodosListComponent implements OnInit {
  todoName: string;
  todoList: ITodo[] = [];
  isAllToggle: boolean = false;
  myselection: string = 'all';
  todoCount: number = 0;
  constructor() {}

  ngOnInit(): void {
    if(JSON.parse(localStorage.getItem('todoList'))) {
    this.todoList = JSON.parse(localStorage.getItem('todoList'));
    this.todoCount = JSON.parse(localStorage.getItem('todoList')).filter((todo) => {
      return !todo.completed;
     }).length;
    }
  }

  addTodo() {
    if(this.todoName) {
    const myTodo = {text: this.todoName, completed: false };
    this.todoList.push(myTodo);
    this.todoName = null;
    localStorage.setItem('todoList', JSON.stringify(this.todoList));
    this.todoCount = JSON.parse(localStorage.getItem('todoList')).filter((todo) => {
      return !todo.completed;
     }).length;
    }
  }

  delete(todo) {
    this.todoList = this.todoList.filter((toDo)=> {
      return toDo != todo;
    });
    localStorage.setItem('todoList', JSON.stringify(this.todoList));
    this.todoCount = JSON.parse(localStorage.getItem('todoList')).filter((todo) => {
      return !todo.completed;
     }).length;
  }

  todoChecked(i) {
    this.todoList[i].completed = !this.todoList[i].completed;
    localStorage.setItem('todoList', JSON.stringify(this.todoList));
    this.todoCount = JSON.parse(localStorage.getItem('todoList')).filter((todo) => {
     return !todo.completed;
    }).length;
  }

  toggleAll() {
    this.isAllToggle = !this.isAllToggle;
    if(this.isAllToggle) {
      this.todoList.forEach((todo) => {
        todo.completed = true;
      });
    } else {
      this.todoList.forEach((todo) => {
        todo.completed = false;
      });
    }
    localStorage.setItem('todoList', JSON.stringify(this.todoList));
    this.todoCount = JSON.parse(localStorage.getItem('todoList')).filter((todo) => {
      return !todo.completed;
     }).length;
  }

  clearCompleted() {
    this.todoList = this.todoList.filter((todo) => {
      return !todo.completed;
    });
    localStorage.setItem('todoList', JSON.stringify(this.todoList));
  }

  toDoFilters(selection) {
    if(selection === 'all') {
     this.myselection = 'all';
     this.todoList = JSON.parse(localStorage.getItem('todoList'));
    } else if(selection === 'active') {
      this.myselection = 'active';
      this.todoList = JSON.parse(localStorage.getItem('todoList'));
      this.todoList = this.todoList.filter((todo) => {
        return !todo.completed;
      })
    } else if(selection === 'completed') {
      this.myselection = 'completed';
      this.todoList = JSON.parse(localStorage.getItem('todoList'));
      this.todoList = this.todoList.filter((todo) => {
        return todo.completed;
      })
    }
  }
}
